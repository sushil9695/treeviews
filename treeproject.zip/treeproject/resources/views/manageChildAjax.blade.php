<ul id="tree1">
@foreach($treeEntries as $treeEntry) 
<li onclick="treeViewAjax({{$treeEntry['entry_id']}},'{{$treeEntry['entry']['name']}}')" id="post-data{{$treeEntry['entry_id']}}"> 
    {{$treeEntry->entry->name}}

</li>
@endforeach 
</ul>