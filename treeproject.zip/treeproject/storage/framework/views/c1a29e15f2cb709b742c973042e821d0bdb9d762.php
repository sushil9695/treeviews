<!DOCTYPE html> 

<html> 

<head> 

    <title>Treeview Example</title> 

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" target="_blank" rel="nofollow"  /> 

    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" target="_blank" rel="nofollow"  rel="stylesheet"> 
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script> 

    <link href="/css/treeview.css" target="_blank" rel="nofollow"  rel="stylesheet"> 

</head> 

<body> 

    <div class="container">      

        <div class="panel panel-primary"> 

            <div class="panel-heading">Manage TreeView</div> 

                <div class="panel-body"> 

                    <div class="row"> 

                        <div class="col-md-6"> 

                            <h3>Tree entry List</h3> 

                            <ul id="tree1"> 

                                <?php $__currentLoopData = $treeEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                                    <li> 

                                        <?php echo e($value->entry->name); ?> 

                                        <?php if(count($value->childs)): ?> 

                                            <?php echo $__env->make('manageChild',['childs' => $value->childs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

                                        <?php endif; ?> 

                                    </li> 

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

                            </ul> 

                        </div> 


                    </div> 

                </div> 

            </div> 

        </div> 

    </div> 

    <script src="/js/treeview.js"></script> 

</body> 

</html> <?php /**PATH E:\task\treeproject\resources\views/treeview.blade.php ENDPATH**/ ?>