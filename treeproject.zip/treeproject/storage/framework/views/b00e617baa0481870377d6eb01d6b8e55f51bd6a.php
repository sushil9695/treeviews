<ul id="tree1">
<?php $__currentLoopData = $treeEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treeEntry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<li onclick="treeViewAjax(<?php echo e($treeEntry['entry_id']); ?>,'<?php echo e($treeEntry['entry']['name']); ?>')" id="post-data<?php echo e($treeEntry['entry_id']); ?>"> 
    <?php echo e($treeEntry->entry->name); ?>


</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
</ul><?php /**PATH E:\task\treeproject\resources\views/manageChildAjax.blade.php ENDPATH**/ ?>