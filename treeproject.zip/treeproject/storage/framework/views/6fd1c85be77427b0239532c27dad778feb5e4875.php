<ul> 

    <?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

        <li> 

            <?php echo e($child->entry->name); ?> 

            <?php if(count($child->childs)): ?>
            
                <?php echo $__env->make('manageChild',['childs' => $child->childs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

            <?php endif; ?> 

        </li> 

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

</ul><?php /**PATH E:\task\treeproject\resources\views/manageChild.blade.php ENDPATH**/ ?>